Smarter AWACS that don't report BRAA at 300nm !
With this mod, BRAA will be reported at :
- less than 80nm for a hot contact
- less than 60nm for a flanking contact
- less than 40nm for a cold contact
Also, the BRAA call is more realistic.

L'AWACS est plus malin, et ne rapporte plus de BRAA à 300nm !
Avec ce mod, les BRAA seront rapportés à :
- moins de 80nm avec un contact hot
- moins de 60nm avec un contact flanking
- moins de 40nm avec un contact cold
Également, le rapport sera plus réaliste.

----------------------------------------
-- Tested with DCS World 2.8.0.32066  --
----------------------------------------

Totally my work !
Zip.
http://www.veaf.org